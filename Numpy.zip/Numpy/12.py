import numpy as np

arr = np.array([10, 25, 55, 40, 70, 35, 90, 45, 60, 20])

print("Original Array:", arr)

arr[arr > 50] = 0

print("Modified Array:", arr)