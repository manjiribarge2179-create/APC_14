import numpy as np

arr = np.array([50, 20, 80, 10, 40, 70, 30])

print("Original Array:", arr)

print("Ascending Order:", np.sort(arr))
print("Descending Order:", np.sort(arr)[::-1])