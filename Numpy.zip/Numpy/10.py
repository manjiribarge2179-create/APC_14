import numpy as np

A = np.array([[1, 2, 3, 4],
              [5, 6, 7, 8],
              [9, 10, 11, 12],
              [13, 14, 15, 16]])

print("Matrix:")
print(A)

print("Sum of each row:", np.sum(A, axis=1))
print("Sum of each column:", np.sum(A, axis=0))