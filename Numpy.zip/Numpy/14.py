import numpy as np

arr = np.array([10, 20, 10, 30, 40, 20, 50, 30, 60, 40])

print("Original Array:", arr)
print("Unique Elements:", np.unique(arr))