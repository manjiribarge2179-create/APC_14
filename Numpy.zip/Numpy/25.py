import numpy as np

arr = np.random.randint(1, 101, size=(3, 4, 5))

flat = arr.flatten()
average = np.mean(flat)

print("3D Array:")
print(arr)

print("\nFlattened Array:")
print(flat)

print("\nElements Greater Than 50:")
print(flat[flat > 50])

print("\nEven Numbers:")
print(flat[flat % 2 == 0])

print("\nAverage:", average)

print("\nElements Less Than Average:")
print(flat[flat < average])