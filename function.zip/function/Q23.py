def total_marks(marks):
    return sum(marks)

def percentage(marks):
    return total_marks(marks) / 5

def grade(percentage):
    if percentage >= 90:
        return "A+"
    elif percentage >= 80:
        return "A"
    elif percentage >= 70:
        return "B"
    elif percentage >= 60:
        return "C"
    elif percentage >= 50:
        return "D"
    else:
        return "F"

def class_average(students):
    total = 0
    for student in students:
        total += percentage(student["marks"])
    return total / len(students)

def highest_scorer(students):
    return max(students, key=lambda student: percentage(student["marks"]))

def lowest_scorer(students):
    return min(students, key=lambda student: percentage(student["marks"]))

students = [
    {"name": "Manjiri", "roll": 1, "marks": [85, 90, 78, 88, 92]},
    {"name": "Riya", "roll": 2, "marks": [75, 80, 72, 70, 78]},
    {"name": "Amit", "roll": 3, "marks": [65, 70, 68, 60, 72]}
]

for student in students:
    p = percentage(student["marks"])
    print("Name:", student["name"])
    print("Roll Number:", student["roll"])
    print("Total:", total_marks(student["marks"]))
    print("Percentage:", p)
    print("Grade:", grade(p))
    print()

print("Class Average:", class_average(students))
print("Highest Scorer:", highest_scorer(students)["name"])
print("Lowest Scorer:", lowest_scorer(students)["name"])