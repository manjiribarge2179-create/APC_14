def consultation_charges(fee):
    return fee

def laboratory_charges(fee):
    return fee

def medicine_charges(fee):
    return fee

def room_charges(days, rate):
    return days * rate

def discount_amount(total, category):
    if category == "senior":
        return total * 0.20
    elif category == "student":
        return total * 0.10
    else:
        return 0

def final_bill(consultation, laboratory, medicine, room, category):
    total = consultation + laboratory + medicine + room
    discount = discount_amount(total, category)
    return total - discount

consultation = consultation_charges(500)
laboratory = laboratory_charges(1000)
medicine = medicine_charges(1500)
room = room_charges(3, 1000)

bill = final_bill(consultation, laboratory, medicine, room, "senior")

print("Final Bill:", bill)