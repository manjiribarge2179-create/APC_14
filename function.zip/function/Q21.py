def total_bill(prices, quantities, discount):
    total = 0
    for i in range(len(prices)):
        total += prices[i] * quantities[i]
    
    discount_amount = total * discount / 100
    return total - discount_amount

print(total_bill([100, 200, 300], [2, 1, 1], 10))