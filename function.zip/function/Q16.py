def second_largest(numbers):
    largest = second = float('-inf')
    
    for num in numbers:
        if num > largest:
            second = largest
            largest = num
        elif num > second and num != largest:
            second = num
    
    return second

print(second_largest([10, 25, 7, 40, 15]))