books = {}

def add_book(book_id, title):
    books[book_id] = {"title": title, "available": True}

def issue_book(book_id):
    if book_id in books and books[book_id]["available"]:
        books[book_id]["available"] = False
        print("Book issued")
    else:
        print("Book not available")

def return_book(book_id):
    if book_id in books:
        books[book_id]["available"] = True
        print("Book returned")
    else:
        print("Book not found")

def search_book(title):
    for book_id, book in books.items():
        if book["title"].lower() == title.lower():
            print("Book found:", book_id, book["title"])
            return
    print("Book not found")

def display_available_books():
    for book_id, book in books.items():
        if book["available"]:
            print(book_id, book["title"])

add_book(1, "Python Programming")
add_book(2, "Data Structures")
add_book(3, "Computer Networks")

issue_book(1)
return_book(1)
search_book("Data Structures")
display_available_books()