def count_element(lst, element):
    count = 0
    for item in lst:
        if item == element:
            count += 1
    return count

print(count_element([1, 2, 3, 2, 4, 2], 2))