def area_of_circle(r):
    return 3.14 * r * r

print(area_of_circle(5))