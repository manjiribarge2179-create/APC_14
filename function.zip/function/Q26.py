def calculate_units_charge(units):
    if units <= 100:
        return units * 2
    elif units <= 200:
        return 100 * 2 + (units - 100) * 3
    elif units <= 300:
        return 100 * 2 + 100 * 3 + (units - 200) * 5
    else:
        return 100 * 2 + 100 * 3 + 100 * 5 + (units - 300) * 7

def calculate_bill(units):
    fixed_charge = 100
    tax_rate = 5
    discount_rate = 10

    unit_charge = calculate_units_charge(units)
    subtotal = unit_charge + fixed_charge
    tax = subtotal * tax_rate / 100
    discount = subtotal * discount_rate / 100
    final_bill = subtotal + tax - discount

    return final_bill

units = 250
print("Electricity Bill:", calculate_bill(units))