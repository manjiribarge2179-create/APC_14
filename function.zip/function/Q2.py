def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

def check_even_odd(n):
    if n % 2 == 0:
        return "Even"
    else:
        return "Odd"

print(factorial(5))
print(check_even_odd(10))