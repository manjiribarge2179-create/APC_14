def calculate(numbers):
    minimum = min(numbers)
    maximum = max(numbers)
    total = sum(numbers)
    average = total / len(numbers)
    
    return minimum, maximum, total, average

result = calculate([10, 20, 30, 40, 50])
print(result)