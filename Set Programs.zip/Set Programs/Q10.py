s1 = {1,2,3,4,5,6,7,8,9,10}
s2 ={1,2,3,4,10,6,11,20}
common = s1.intersection(s2)
print("Common elements:", common)