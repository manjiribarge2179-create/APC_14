filename = input("Enter file name: ")
word = input("Enter word to search: ")

with open(filename, "r") as file:
    text = file.read()

words = text.lower().split()
word = word.lower()

frequency = words.count(word)

print("Frequency of", word, "is:", frequency)