products = [
    ("Laptop", 50000, 1),
    ("Mouse", 800, 2),
    ("Keyboard", 1500, 3),
    ("Headphones", 2000, 2)
]

def total_value(product):
    return product[1] * product[2]

product_values = list(map(lambda p: (p[0], total_value(p)), products))

expensive_products = list(filter(lambda p: p[1] > 1000, products))

sorted_products = sorted(product_values, key=lambda p: p[1])

print("Total value of each product:")
print(product_values)

print("Products costing more than 1000:")
print(expensive_products)

print("Products sorted by total value:")
print(sorted_products)