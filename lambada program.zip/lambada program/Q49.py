students = [
    ("Manjiri", 85),
    ("Riya", 72),
    ("Amit", 90),
    ("Sneha", 78),
    ("Rahul", 65)
]

def average_marks(students):
    marks = list(map(lambda student: student[1], students))
    return sum(marks) / len(marks)

def above_75(students):
    return list(filter(lambda student: student[1] > 75, students))

def sort_students(students):
    return sorted(students, key=lambda student: student[1])

print("Average Marks:", average_marks(students))
print("Students above 75:", above_75(students))
print("Sorted Students:", sort_students(students))