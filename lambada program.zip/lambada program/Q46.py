words = ["apple", "cat", "banana", "dog", "elephant"]

words.sort(key=lambda word: len(word))

print(words)