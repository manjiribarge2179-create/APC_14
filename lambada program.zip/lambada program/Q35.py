is_even = lambda n: n % 2 == 0

print(is_even(10))