numbers = [-5, 10, -2, 20, 0, 15, -8]

positive_numbers = list(filter(lambda x: x > 0, numbers))

print(positive_numbers)