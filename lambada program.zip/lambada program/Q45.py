words = ["apple", "computer", "python", "elephant", "book", "programming"]

result = list(filter(lambda word: len(word) > 5, words))

print(result)