employees = [("Manjiri", 50000), ("Riya", 35000), ("Amit", 60000), ("Sneha", 45000)]

employees.sort(key=lambda employee: employee[1])

print(employees)