numbers = [20, 55, 30, 75, 45, 90, 60]

result = list(filter(lambda x: x > 50, numbers))

print(result)