words = ["apple", "computer", "python", "elephant", "book", "programming"]

def word_lengths(words):
    return list(map(lambda word: len(word), words))

def long_words(words):
    return list(filter(lambda word: len(word) > 5, words))

def sort_by_length(words):
    return sorted(words, key=lambda word: len(word))

print("Length of every word:", word_lengths(words))
print("Words having more than 5 characters:", long_words(words))
print("Words sorted by length:", sort_by_length(words))