students = [("Manjiri", 85), ("Riya", 72), ("Amit", 90), ("Sneha", 78)]

students.sort(key=lambda student: student[1])

print(students)