employees = [
    ("Manjiri", "IT", 55000),
    ("Riya", "HR", 45000),
    ("Amit", "IT", 70000),
    ("Sneha", "Finance", 60000)
]

high_salary = list(filter(lambda emp: emp[2] > 50000, employees))

increased_salary = list(map(lambda emp: (emp[0], emp[1], emp[2] * 1.10), employees))

sorted_employees = sorted(employees, key=lambda emp: emp[2])

print("Employees earning more than 50000:")
print(high_salary)

print("Salaries after 10% increase:")
print(increased_salary)

print("Employees sorted by salary:")
print(sorted_employees)