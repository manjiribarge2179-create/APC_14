d = {"Name": "Shravani","Roll No": 16, "Branch": "Computer Science", "Marks":95}
print("Dictionary:", d)